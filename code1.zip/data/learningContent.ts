import type { LearningArticle } from '../types.ts';

export const learningArticles: LearningArticle[] = [
  {
    slug: 'what-is-prompt-engineering',
    title: 'What is Prompt Engineering?',
    summary: 'Learn the art of crafting effective prompts to get the best results from AI models.',
    isPro: false,
    content: `
      <p>At its core, <strong>Prompt Engineering</strong> is the art and science of designing effective inputs (prompts) to guide Artificial Intelligence (AI) models, like Spark, toward desired outputs. Think of it as learning how to have a clear and productive conversation with an AI.</p>
      <p>Instead of just asking a simple question, you learn to provide context, instructions, and examples to get more accurate, relevant, and creative responses.</p>
      
      <h3 class="text-xl font-semibold mt-6 mb-2">Why is it Important?</h3>
      <p>The quality of the AI's output is directly tied to the quality of your input. A vague prompt leads to a vague answer. A well-crafted prompt acts like a precise set of instructions, minimizing guesswork for the AI and maximizing the value of its response.</p>
      
      <h3 class="text-xl font-semibold mt-6 mb-2">A Simple Example:</h3>
      <ul class="list-disc list-inside space-y-2">
        <li><strong>Vague Prompt:</strong> "Tell me about cars."</li>
        <li><strong>Engineered Prompt:</strong> "Explain the basic differences between an internal combustion engine and an electric vehicle motor for someone who isn't a mechanic."</li>
      </ul>
      <p class="mt-2">The second prompt gives the AI a clear task, a target audience, and specific constraints, resulting in a much more useful answer.</p>
    `
  },
  {
    slug: 'understanding-shot-learning',
    title: 'Understanding 0-Shot vs. 1-Shot',
    summary: 'Discover how providing examples (or not) can dramatically change AI behavior.',
    isPro: false,
    content: `
      <p>In the world of AI, a "shot" refers to an example given to the model within the prompt itself. This is a fundamental concept in prompt engineering that dramatically influences the AI's response style and format.</p>
      
      <h3 class="text-xl font-semibold mt-6 mb-2">Zero-Shot (0-Shot) Prompting</h3>
      <p>This is the most basic form of interaction. You ask the AI to perform a task without giving it any prior examples. You rely on the model's pre-existing knowledge to understand and execute the request.</p>
      <p><strong>When to use it:</strong> For simple, direct questions and tasks where the desired format is standard. Spark Basic defaults to this.</p>
      <pre class="bg-slate-100 p-3 rounded-md my-2"><code>User: "Summarize the concept of supply and demand in one sentence."</code></pre>
      
      <h3 class="text-xl font-semibold mt-6 mb-2">One-Shot (1-Shot) Prompting</h3>
      <p>Here, you provide a single example of the task you want the AI to perform. This helps the model understand the context and, more importantly, the desired format of the output.</p>
      <p><strong>When to use it:</strong> When you need the AI to follow a specific structure, tone, or style. This is a feature of Spark Pro.</p>
      <pre class="bg-slate-100 p-3 rounded-md my-2"><code>User: 
Example:
Q: What is the capital of France?
A: The capital of France is Paris.

Now, answer this:
Q: What is the capital of Japan?</code></pre>
      <p class="mt-2">By providing one example, you guide the AI to give a concise, direct answer rather than a long paragraph.</p>
    `
  },
  {
    slug: 'advanced-chain-of-thought',
    title: 'Advanced: Chain-of-Thought Prompting',
    summary: 'Unlock complex reasoning in AI by guiding it to "think step-by-step". (Spark Pro)',
    isPro: true,
    content: `
      <p><strong>Chain-of-Thought (CoT)</strong> prompting is an advanced technique that encourages an AI model to break down a complex problem into a series of intermediate, logical steps before giving a final answer. It essentially mimics a human's process of reasoning through a problem.</p>
      <p>This is one of the most powerful features of Spark Pro, enabling you to tackle multi-step reasoning, calculation, and logic puzzles that simpler prompts can't handle.</p>
      
      <h3 class="text-xl font-semibold mt-6 mb-2">How It Works</h3>
      <p>Instead of just asking for the answer, you instruct the model to "think step-by-step" or provide an example that shows a reasoning process.</p>
      
      <h3 class="text-xl font-semibold mt-6 mb-2">Example: A Logic Problem</h3>
      <p><strong>Standard Prompt:</strong></p>
      <pre class="bg-slate-100 p-3 rounded-md my-2"><code>A cafeteria had 23 apples. If they used 20 for lunch and bought 6 more, how many apples do they have?</code></pre>
      <p>An AI might get this right, but for more complex problems, it can fail.
      
      <p class="mt-4"><strong>Chain-of-Thought Prompt:</strong></p>
      <pre class="bg-slate-100 p-3 rounded-md my-2"><code>A cafeteria had 23 apples. If they used 20 for lunch and bought 6 more, how many apples do they have?

Let's think step by step:
1. Start with the initial number of apples: 23.
2. They used 20 for lunch, so we subtract 20: 23 - 20 = 3.
3. They bought 6 more, so we add 6: 3 + 6 = 9.
Final Answer: They have 9 apples.</code></pre>
      <p class="mt-2">By forcing the model to articulate its reasoning, you dramatically increase the accuracy of the final result. The "Chain-Prompt" button in Spark Pro automates this process, instructing the AI to apply this thinking method to your query.</p>
    `
  }
];
