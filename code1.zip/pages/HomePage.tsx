import React from 'react';
import { Link } from 'react-router-dom';
import Card from '../components/ui/Card.tsx';
import Button from '../components/ui/Button.tsx';
import BasicAIDemo from '../components/ai/BasicAIDemo.tsx';
import { learningArticles } from '../data/learningContent.ts';

const CheckIcon = () => (
  <svg className="w-6 h-6 text-green-500 mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path></svg>
);

const ArrowRightIcon = () => (
    <svg className="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 7l5 5m0 0l-5 5m5-5H6"></path></svg>
);

export default function HomePage() {
  return (
    <div className="space-y-16 md:space-y-24">
      {/* Hero Section */}
      <section className="text-center pt-12">
        <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight text-gray-900">
          Unlock Your Future with <span className="text-primary-600">AI</span>
        </h1>
        <p className="mt-4 max-w-2xl mx-auto text-lg md:text-xl text-slate-600">
          Vibe Coding of Augusta is your partner in navigating the world of Artificial Intelligence. We make complex technology simple, powerful, and accessible for everyone.
        </p>
        <div className="mt-8">
          <Button as={Link} to="/register" className="text-lg px-8 py-3">
            Get Started
          </Button>
        </div>
      </section>

      {/* AI Demo Section */}
      <section id="demo">
        <BasicAIDemo />
      </section>

      {/* About Us Section */}
      <section id="about">
        <Card className="text-center">
          <h2 className="text-3xl font-bold mb-4">Stop Guessing. Start Winning with AI.</h2>
          <p className="text-slate-600 max-w-3xl mx-auto">
            For 30 years, I've been in the trenches of business. I know what works. AI isn't a trend; it's the new baseline for success. We cut through the hype and give you powerful, straightforward AI tools that deliver results. No wasted time, no complexity. Just a direct path to making your business smarter, faster, and more profitable. Let's get to work.
          </p>
        </Card>
      </section>

      {/* AI Products Section */}
      <section id="products">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Our AI Solutions</h2>
        <div className="grid md:grid-cols-2 gap-8">
          {/* Spark Basic */}
          <Card className="flex flex-col">
            <h3 className="text-2xl font-bold text-primary-700">Spark Basic</h3>
            <p className="text-slate-500 mt-1">Your helpful, goal-oriented friend.</p>
            <p className="mt-4 text-slate-600 flex-grow">An AI designed to help you reach your goals by answering questions with a positive influence. It learns from you to give personalized advice.</p>
            <ul className="mt-6 space-y-3">
              <li className="flex items-start"><CheckIcon /> <span><span className="font-semibold">0-Shot Prompt Enhancer</span> for simple, direct answers.</span></li>
              <li className="flex items-start"><CheckIcon /> <span><span className="font-semibold">Personalized Memory</span> to remember your goals and details.</span></li>
              <li className="flex items-start"><CheckIcon /> <span><span className="font-semibold">Learning Resources</span> to understand basic AI concepts.</span></li>
            </ul>
            <div className="mt-8 pt-6 border-t flex-grow flex flex-col justify-end">
              <p className="text-3xl font-bold text-center">$9.99<span className="text-lg font-normal text-slate-500">/month</span></p>
              <p className="text-center text-green-600 font-semibold mt-2">3 Days Free!</p>
              <Button as={Link} to="/checkout/spark-basic" className="w-full mt-4">Get Started</Button>
            </div>
          </Card>
          {/* Spark Pro */}
          <Card className="flex flex-col border-2 border-primary-600 relative">
            <div className="absolute top-0 right-6 -mt-4 bg-primary-600 text-white px-3 py-1 rounded-full text-sm font-semibold">Most Popular</div>
            <h3 className="text-2xl font-bold text-primary-700">Spark Pro</h3>
            <p className="text-slate-500 mt-1">The ultimate AI power-up.</p>
            <p className="mt-4 text-slate-600 flex-grow">Builds on Spark Basic with advanced tools for complex problem-solving and deeper learning, giving you a professional edge.</p>
            <ul className="mt-6 space-y-3">
              <li className="flex items-start"><CheckIcon /> <span><span className="font-semibold">4-Button Prompt Enhancer</span> (0, 1, Few-shot, Chain-prompt).</span></li>
              <li className="flex items-start"><CheckIcon /> <span><span className="font-semibold">4x Enhanced Memory</span> for superior contextual understanding.</span></li>
              <li className="flex items-start"><CheckIcon /> <span><span className="font-semibold">Advanced Learning</span> to master prompt engineering.</span></li>
            </ul>
            <div className="mt-8 pt-6 border-t flex-grow flex flex-col justify-end">
              <p className="text-3xl font-bold text-center">$49.99<span className="text-lg font-normal text-slate-500">/month</span></p>
              <p className="text-center text-slate-500 font-semibold mt-2">No free trial.</p>
              <Button as={Link} to="/checkout/spark-pro" className="w-full mt-4">Subscribe Now</Button>
            </div>
          </Card>
        </div>
      </section>

      {/* Learning Center Section */}
      <section id="learning">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-4">Knowledge is Power</h2>
        <p className="text-center text-slate-600 max-w-2xl mx-auto mb-12">We don't just sell tools; we create experts. Dive into our free resources and learn the fundamentals that will put you ahead of the competition.</p>
        <div className="grid md:grid-cols-3 gap-8">
          {learningArticles.slice(0, 3).map(article => (
            <Card key={article.slug} className="flex flex-col">
              <h3 className="text-xl font-bold text-primary-800">{article.title}</h3>
              <p className="text-slate-500 mt-2 flex-grow">{article.summary}</p>
              <Link to={`/learning/${article.slug}`} className="flex items-center font-semibold text-primary-600 mt-4 hover:text-primary-700">
                Read More <ArrowRightIcon />
              </Link>
            </Card>
          ))}
        </div>
      </section>

      {/* Key Differentiators */}
      <section id="differentiators" className="grid md:grid-cols-3 gap-8 text-center">
          <Card>
              <h3 className="text-xl font-bold mb-2">Smarter Recall, Faster Results</h3>
              <p className="text-slate-600">Our AI remembers what matters, so you don't have to repeat yourself. Pure efficiency.</p>
          </Card>
          <Card>
              <h3 className="text-xl font-bold mb-2">Answers in an Instant</h3>
              <p className="text-slate-600">Time is money. We don't waste either. Get the insights you need, right when you need them.</p>
          </Card>
          <Card>
              <h3 className="text-xl font-bold mb-2">Master AI, Master Your Future</h3>
              <p className="text-slate-600">The AI revolution is here. We give you the tools and knowledge to lead it, not be left behind. Secure your advantage.</p>
          </Card>
      </section>

      {/* White-label Products */}
      <section id="services">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Build Your Online Presence</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8 text-center">
          <div className="p-6 bg-white rounded-lg shadow-md">
            <h3 className="font-bold">Domain Names</h3>
          </div>
          <div className="p-6 bg-white rounded-lg shadow-md">
            <h3 className="font-bold">Web Hosting</h3>
          </div>
          <div className="p-6 bg-white rounded-lg shadow-md">
            <h3 className="font-bold">Professional Email</h3>
          </div>
          <div className="p-6 bg-white rounded-lg shadow-md">
            <h3 className="font-bold">SSL Certificates</h3>
          </div>
        </div>
      </section>
    </div>
  );
}
