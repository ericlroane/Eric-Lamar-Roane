import React from 'react';
import { useParams, Link, NavLink, Navigate } from 'react-router-dom';
import { learningArticles } from '../data/learningContent.ts';
import Card from '../components/ui/Card.tsx';
import { useAuth } from '../hooks/useAuth.tsx';

const ProTag = () => (
  <span className="ml-2 text-xs font-semibold bg-primary-100 text-primary-700 px-2 py-0.5 rounded-full">
    PRO
  </span>
);

export default function LearningCenterPage() {
  const { slug } = useParams();
  const { userProfile } = useAuth();
  const article = learningArticles.find(a => a.slug === slug);

  if (!article) {
    // Redirect to the first article if the slug is invalid
    return <Navigate to={`/learning/${learningArticles[0].slug}`} replace />;
  }

  // Pro content restriction
  const isProContent = article.isPro;
  const canViewPro = userProfile?.subscription === 'Spark Pro';

  return (
    <div className="grid lg:grid-cols-4 gap-8">
      {/* Sidebar */}
      <aside className="lg:col-span-1">
        <Card className="sticky top-24">
          <h2 className="text-lg font-bold mb-4">Topics</h2>
          <nav className="space-y-2">
            {learningArticles.map(navArticle => (
              <NavLink
                key={navArticle.slug}
                to={`/learning/${navArticle.slug}`}
                className={({ isActive }) =>
                  `block px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    isActive
                      ? 'bg-primary-100 text-primary-700'
                      : 'text-slate-600 hover:bg-slate-100'
                  }`
                }
              >
                {navArticle.title}
                {navArticle.isPro && <ProTag />}
              </NavLink>
            ))}
          </nav>
        </Card>
      </aside>

      {/* Main Content */}
      <main className="lg:col-span-3">
        <Card>
          <article className="prose prose-slate max-w-none prose-h1:text-3xl prose-h1:font-bold prose-h3:font-semibold prose-a:text-primary-600 hover:prose-a:text-primary-700">
            <h1>
              {article.title}
              {article.isPro && <ProTag />}
            </h1>
            
            {isProContent && !canViewPro ? (
              <div className="mt-6 p-6 rounded-lg border-2 border-primary-500 bg-primary-50 text-center">
                <h3 className="text-xl font-bold text-primary-800">This is a Spark Pro Resource</h3>
                <p className="mt-2 text-slate-600">Upgrade to Spark Pro to unlock advanced learning materials, a more powerful AI with 4x memory, and advanced prompt engineering tools.</p>
                <Link to="/#products" className="mt-4 inline-block bg-primary-600 text-white px-6 py-2 rounded-md font-semibold hover:bg-primary-700">
                  View Plans
                </Link>
              </div>
            ) : (
              <div dangerouslySetInnerHTML={{ __html: article.content }} />
            )}
          </article>
        </Card>
      </main>
    </div>
  );
}
