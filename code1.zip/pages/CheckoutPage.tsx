import React, { useState } from 'react';
import { useParams, useNavigate, Link, Navigate } from 'react-router-dom';
import Card from '../components/ui/Card.tsx';
import Button from '../components/ui/Button.tsx';
import { useAuth } from '../hooks/useAuth.tsx';
import { updateUserSubscription } from '../services/firebase.ts';
import type { Plan } from '../types.ts';

const plans = {
  'spark-basic': { name: 'Spark Basic', price: 9.99, features: ['3 Days Free Trial', '0-Shot Prompt Enhancer', 'Personalized Memory', 'Basic Learning Resources'] },
  'spark-pro': { name: 'Spark Pro', price: 49.99, features: ['All Basic Features', '4-Button Prompt Enhancer', '4x Enhanced Memory', 'Advanced Learning Resources'] },
};

const CheckIcon = () => (
  <svg className="w-5 h-5 text-green-500 mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path></svg>
);

export default function CheckoutPage() {
  const { plan } = useParams<{ plan: Plan }>();
  const { currentUser, userProfile, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState('');

  if (!plan || !Object.keys(plans).includes(plan)) {
    return <Navigate to="/" replace />;
  }

  const selectedPlan = plans[plan];

  const handleSubscription = async () => {
    if (!currentUser || !userProfile) {
      navigate('/login');
      return;
    }

    setIsProcessing(true);
    setError('');
    try {
      await updateUserSubscription(currentUser.uid, selectedPlan.name as 'Spark Basic' | 'Spark Pro');
      // On success, navigate to the dashboard to see the changes
      navigate('/dashboard');
    } catch (err) {
      console.error("Subscription failed:", err);
      setError('There was an error processing your subscription. Please try again.');
      setIsProcessing(false);
    }
  };

  if (authLoading) {
    return <div>Loading...</div>;
  }

  if (!currentUser) {
    return (
        <div className="text-center">
            <h2 className="text-2xl font-bold">Please log in to continue</h2>
            <p className="mt-2">You need to be logged in to subscribe to a plan.</p>
            <Button as={Link} to={`/login`} className="mt-4">Login</Button>
        </div>
    )
  }

  return (
    <div className="max-w-2xl mx-auto">
      <Card>
        <h1 className="text-3xl font-bold text-center mb-2">Complete Your Subscription</h1>
        <p className="text-center text-slate-500 mb-8">You are subscribing to <span className="font-semibold text-primary-600">{selectedPlan.name}</span>.</p>

        <div className="bg-slate-50 p-6 rounded-lg border">
          <h2 className="text-xl font-semibold">{selectedPlan.name}</h2>
          <p className="text-3xl font-bold my-4">${selectedPlan.price}<span className="text-lg font-normal text-slate-500">/month</span></p>
          <ul className="space-y-2">
            {selectedPlan.features.map(feature => (
              <li key={feature} className="flex items-center text-slate-600">
                <CheckIcon /> {feature}
              </li>
            ))}
          </ul>
        </div>

        <div className="mt-8">
          <h3 className="text-lg font-semibold">Payment Simulation</h3>
          <p className="text-sm text-slate-500 mt-1">
            This is a demonstration. No payment will be processed. Clicking "Confirm" will activate your selected plan on your account.
          </p>
          {error && <p className="text-red-500 mt-2">{error}</p>}
          <Button
            onClick={handleSubscription}
            isLoading={isProcessing}
            className="w-full mt-4"
            size="lg"
          >
            {isProcessing ? 'Processing...' : `Confirm Subscription to ${selectedPlan.name}`}
          </Button>
        </div>
      </Card>
    </div>
  );
}
