import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth.tsx';
import { updateUserProfile } from '../services/firebase.ts';
import { getSparkResponse } from '../services/aiService.ts';
import Card from '../components/ui/Card.tsx';
import Button from '../components/ui/Button.tsx';
import type { ChatMessage, UserProfile } from '../types.ts';

type Enhancement = '0-shot' | '1-shot' | 'few-shot' | 'chain-prompt';

// Define memory limits for different plans
const MEMORY_LIMIT_BASIC = 8; // 4 user messages + 4 model responses
const MEMORY_LIMIT_PRO = 32; // 16 user messages + 16 model responses (4x Basic)

const UserIcon = () => <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center font-bold text-slate-600">U</div>;
const SparkIcon = () => <div className="w-8 h-8 rounded-full bg-primary-200 flex items-center justify-center font-bold text-primary-700">S</div>;

const SubscriptionStatus = () => {
    const { userProfile } = useAuth();

    if (!userProfile?.subscription) {
        return (
            <Card>
                <h2 className="text-xl font-bold mb-2">No Active Plan</h2>
                <p className="text-slate-500 mb-4">Subscribe to unlock Spark's full potential.</p>
                <Button as={Link} to="/#products" className="w-full">View Plans</Button>
            </Card>
        )
    }

    return (
        <Card>
            <h2 className="text-xl font-bold mb-2">Your Plan</h2>
            <p className="text-lg font-semibold text-primary-700">{userProfile.subscription}</p>
            <p className="text-sm text-slate-500 mt-1">
                {userProfile.subscriptionEndDate 
                    ? `Renews on: ${new Date(userProfile.subscriptionEndDate).toLocaleDateString()}`
                    : 'No end date specified.'
                }
            </p>
            {userProfile.subscription === 'Spark Basic' && (
                 <Button as={Link} to="/checkout/spark-pro" variant="secondary" className="w-full mt-4">Upgrade to Pro</Button>
            )}
        </Card>
    )
}

export default function DashboardPage() {
  const { userProfile, loading: authLoading, refreshUserProfile } = useAuth();
  const [persona, setPersona] = useState<Partial<UserProfile>>({ name: '', job: '', birthday: '' });
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const [prompt, setPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [enhancement, setEnhancement] = useState<Enhancement>('0-shot');
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (userProfile) {
      setPersona({
        name: userProfile.name || '',
        job: userProfile.job || '',
        birthday: userProfile.birthday || '',
      });
    }
  }, [userProfile]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatHistory]);

  const handlePersonaChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPersona({ ...persona, [e.target.name]: e.target.value });
  };

  const handlePersonaSave = async () => {
    if (!userProfile) return;
    setIsSaving(true);
    await updateUserProfile(userProfile.uid, persona);
    await refreshUserProfile(); // Refresh context
    setIsSaving(false);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim() || isLoading || !userProfile) return;

    const userMessage: ChatMessage = { id: Date.now().toString(), role: 'user', text: prompt };
    const newChatHistory = [...chatHistory, userMessage];
    setChatHistory(newChatHistory);
    setPrompt('');
    setIsLoading(true);

    // Determine memory limit based on subscription
    const memoryLimit = userProfile.subscription === 'Spark Pro' ? MEMORY_LIMIT_PRO : MEMORY_LIMIT_BASIC;
    const historyForAI = newChatHistory.slice(-memoryLimit -1, -1); // Get relevant history, excluding the current prompt

    const responseText = await getSparkResponse(prompt, persona, enhancement, historyForAI);
    
    const modelMessage: ChatMessage = { id: (Date.now() + 1).toString(), role: 'model', text: responseText };
    setChatHistory(prev => [...prev, modelMessage]);
    setIsLoading(false);
  };

  if (authLoading) {
    return <div>Loading dashboard...</div>;
  }

  return (
    <div className="grid lg:grid-cols-3 gap-8">
      {/* Left Column: Persona & Learning */}
      <div className="lg:col-span-1 space-y-8">
        <SubscriptionStatus />
        <Card>
          <h2 className="text-xl font-bold mb-4">Your Persona</h2>
          <p className="text-sm text-slate-500 mb-4">Help Spark get to know you better for more personalized interactions.</p>
          <div className="space-y-4">
            <input name="name" value={persona.name} onChange={handlePersonaChange} placeholder="Your Name" className="w-full p-2 border rounded-md" />
            <input name="job" value={persona.job} onChange={handlePersonaChange} placeholder="Your Job/Occupation" className="w-full p-2 border rounded-md" />
            <input name="birthday" value={persona.birthday} onChange={handlePersonaChange} placeholder="Your Birthday (e.g., Jan 1st)" className="w-full p-2 border rounded-md" />
            <Button onClick={handlePersonaSave} isLoading={isSaving} className="w-full">
              {saveSuccess ? 'Saved!' : 'Save Persona'}
            </Button>
          </div>
        </Card>
        <Card>
          <h2 className="text-xl font-bold mb-4">Learning Resources</h2>
          <ul className="space-y-2 text-primary-700">
            <li><Link to="/learning/what-is-prompt-engineering" className="hover:underline">What is Prompt Engineering?</Link></li>
            <li><Link to="/learning/understanding-shot-learning" className="hover:underline">Understanding 0-Shot vs 1-Shot</Link></li>
            {userProfile?.subscription === 'Spark Pro' && (
              <li><Link to="/learning/advanced-chain-of-thought" className="hover:underline">Advanced: Chain-of-Thought</Link></li>
            )}
          </ul>
        </Card>
      </div>

      {/* Right Column: Spark AI Chat */}
      <div className="lg:col-span-2">
        <Card className="!p-0 flex flex-col h-[70vh]">
          <div className="p-4 border-b">
            <h2 className="text-xl font-bold">Spark AI</h2>
            <p className="text-sm text-slate-500">Your goal-oriented AI assistant.</p>
          </div>
          <div className="flex-grow p-4 overflow-y-auto bg-slate-50">
            <div className="space-y-4">
              {chatHistory.map((msg) => (
                <div key={msg.id} className={`flex items-start gap-3 ${msg.role === 'user' ? 'justify-end' : ''}`}>
                  {msg.role === 'model' && <SparkIcon />}
                  <div className={`max-w-lg p-3 rounded-lg ${msg.role === 'user' ? 'bg-primary-600 text-white' : 'bg-white shadow-sm'}`}>
                    <p className="text-sm whitespace-pre-wrap">{msg.text}</p>
                  </div>
                  {msg.role === 'user' && <UserIcon />}
                </div>
              ))}
              {isLoading && (
                <div className="flex items-start gap-3">
                  <SparkIcon />
                  <div className="max-w-lg p-3 rounded-lg bg-white shadow-sm">
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-slate-400 rounded-full animate-pulse"></div>
                      <div className="w-2 h-2 bg-slate-400 rounded-full animate-pulse [animation-delay:0.2s]"></div>
                      <div className="w-2 h-2 bg-slate-400 rounded-full animate-pulse [animation-delay:0.4s]"></div>
                    </div>
                  </div>
                </div>
              )}
              <div ref={chatEndRef} />
            </div>
          </div>
          <div className="p-4 border-t bg-white">
            <div className="mb-2 flex items-center gap-2 flex-wrap">
              <span className="text-sm font-medium">Prompt Enhancer:</span>
              <Button size="sm" variant={enhancement === '0-shot' ? 'primary' : 'secondary'} onClick={() => setEnhancement('0-shot')}>0-Shot</Button>
              {userProfile?.subscription === 'Spark Pro' && (
                <>
                  <Button size="sm" variant={enhancement === '1-shot' ? 'primary' : 'secondary'} onClick={() => setEnhancement('1-shot')}>1-Shot</Button>
                  <Button size="sm" variant={enhancement === 'few-shot' ? 'primary' : 'secondary'} onClick={() => setEnhancement('few-shot')}>Few-Shot</Button>
                  <Button size="sm" variant={enhancement === 'chain-prompt' ? 'primary' : 'secondary'} onClick={() => setEnhancement('chain-prompt')}>Chain-Prompt</Button>
                </>
              )}
            </div>
            <form onSubmit={handleSendMessage} className="flex gap-2">
              <input
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Ask Spark anything..."
                className="flex-grow p-2 border rounded-md focus:ring-primary-500 focus:border-primary-500"
                disabled={isLoading || !userProfile?.subscription}
              />
              <Button type="submit" isLoading={isLoading} disabled={!userProfile?.subscription}>Send</Button>
            </form>
             {!userProfile?.subscription && <p className="text-xs text-red-500 mt-2">You need an active subscription to use the AI chat.</p>}
          </div>
        </Card>
      </div>
    </div>
  );
}
