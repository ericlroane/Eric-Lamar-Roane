
const { onCall } = require("firebase-functions/v2/https");
const { initializeApp } = require("firebase-admin/app");
const { GoogleGenAI } = require("@google/genai");

initializeApp();

// Access your Gemini API key as an environment variable
const geminiApiKey = process.env.GEMINI_API_KEY;
if (!geminiApiKey) {
    console.error("CRITICAL ERROR: GEMINI_API_KEY environment variable not set.");
}
const ai = new GoogleGenAI({ apiKey: geminiApiKey, vertexai: true });

// Helper function from client-side, now on the server
const buildSystemInstruction = (persona) => {
    let instruction = `You are Spark, a helpful, goal-oriented AI friend with a positive influence. Your primary purpose is to help the user achieve their goals by answering their questions clearly and concisely. You do not generate new, creative content like stories or poems unless specifically instructed to do so as part of a question. Your tone is always positive and encouraging.`;

    if (persona && (persona.name || persona.job || persona.birthday)) {
        instruction += "\n\nUse the following information about the user to personalize your responses:\n";
        if (persona.name) instruction += `- Name: ${persona.name}\n`;
        if (persona.job) instruction += `- Job: ${persona.job}\n`;
        if (persona.birthday) instruction += `- Birthday: ${persona.birthday}\n`;
    }
    return instruction;
};

// Secure function for authenticated users
exports.getSparkResponse = onCall(async (request) => {
    if (!request.auth) {
        throw new functions.https.HttpsError(
            'unauthenticated',
            'The function must be called while authenticated.'
        );
    }

    const { prompt, persona, history } = request.data;

    try {
        const systemInstruction = buildSystemInstruction(persona);
        
        const contents = [
            ...history.map(msg => ({
                role: msg.role,
                parts: [{ text: msg.text }]
            })),
            {
                role: 'user',
                parts: [{ text: prompt }]
            }
        ];

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: contents,
            config: {
                systemInstruction: systemInstruction,
            }
        });
        
        return { text: response.text };

    } catch (error) {
        console.error("Error calling Gemini API from Cloud Function:", error);
        throw new functions.https.HttpsError('internal', 'Failed to get response from AI.', error);
    }
});

// Public function for the homepage demo
exports.getPublicSparkResponse = onCall(async (request) => {
    const { prompt } = request.data;

    if (!prompt || typeof prompt !== 'string' || prompt.length > 1000) {
         throw new functions.https.HttpsError(
            'invalid-argument',
            'A valid prompt must be provided.'
        );
    }

    try {
        // Use a generic system instruction, no persona.
        const systemInstruction = buildSystemInstruction(null);

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: [{ role: 'user', parts: [{ text: prompt }] }],
            config: {
                systemInstruction: systemInstruction,
            }
        });
        
        return { text: response.text };

    } catch (error) {
        console.error("Error in public Gemini API call:", error);
        throw new functions.https.HttpsError('internal', 'Failed to get public response from AI.', error);
    }
});
