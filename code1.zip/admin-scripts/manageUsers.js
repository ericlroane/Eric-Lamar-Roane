// This script uses CommonJS because Node.js support for ESM in simple scripts can vary.
const admin = require('firebase-admin');

// The script expects the service account key to be in the same directory.
try {
  const serviceAccount = require('./serviceAccountKey.json');
  
  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
    databaseURL: "https://studio-2047789106-e4e02-default-rtdb.firebaseio.com"
  });

} catch (error) {
  console.error('\x1b[31m%s\x1b[0m', 'Error: `serviceAccountKey.json` not found.');
  console.error('Please download it from your Firebase project settings and place it in the `admin-scripts` directory.');
  console.error('Follow the instructions in `admin-scripts/README.md`.');
  process.exit(1);
}


const db = admin.firestore();
const auth = admin.auth();

const listAllUsers = async () => {
  try {
    const userRecords = await auth.listUsers();
    const users = userRecords.users;
    
    if (users.length === 0) {
      console.log('No users found in Firebase Authentication.');
      return;
    }

    console.log('Fetching user profiles from Firestore...');
    const profiles = await Promise.all(users.map(async (user) => {
      const userDoc = await db.collection('users').doc(user.uid).get();
      const profileData = userDoc.data();
      return {
        uid: user.uid,
        email: user.email,
        role: profileData?.role || 'N/A',
      };
    }));

    console.log('\n--- All Project Users ---');
    console.table(profiles);
    console.log('-------------------------\n');

  } catch (error) {
    console.error('Error listing users:', error);
  }
};

const setUserRole = async (email, role) => {
  const validRoles = ['Super Administrator', 'Administrator', 'Manager', 'Salesperson', 'AI Helper'];
  if (!validRoles.includes(role)) {
    console.error(`Error: Invalid role "${role}".`);
    console.error(`Available roles are: ${validRoles.join(', ')}`);
    return;
  }

  try {
    console.log(`Finding user with email: ${email}...`);
    const userRecord = await auth.getUserByEmail(email);
    const uid = userRecord.uid;
    
    console.log(`Found user UID: ${uid}. Setting role to "${role}"...`);
    
    const userRef = db.collection('users').doc(uid);
    await userRef.update({ role: role });
    
    console.log('\x1b[32m%s\x1b[0m', `Successfully updated role for ${email} to ${role}.`);

  } catch (error) {
    if (error.code === 'auth/user-not-found') {
      console.error(`Error: No user found with the email "${email}".`);
    } else {
      console.error('Error setting user role:', error);
    }
  }
};

// --- Script Execution ---
const args = process.argv.slice(2);

const main = async () => {
  if (args.length === 0) {
    console.log('Usage: node manageUsers.js [--list] [--setRole <email> <role>]');
    return;
  }

  if (args[0] === '--list') {
    await listAllUsers();
  } else if (args[0] === '--setRole') {
    if (args.length !== 3) {
      console.error('Error: --setRole requires an email and a role.');
      console.error('Example: node manageUsers.js --setRole test@example.com Manager');
      return;
    }
    const [, email, role] = args;
    await setUserRole(email, role);
  } else {
    console.error(`Unknown command: ${args[0]}`);
  }
  
  // Firestore does not automatically exit, so we do it manually.
  process.exit(0);
};

main();
