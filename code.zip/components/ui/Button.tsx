
import React from 'react';

interface ButtonProps {
  children: React.ReactNode;
  variant?: 'primary' | 'secondary' | 'danger';
  isLoading?: boolean;
  as?: React.ElementType;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  [key:string]: any;
}

const Button: React.FC<ButtonProps> = ({ 
  children, 
  variant = 'primary', 
  isLoading = false, 
  className = '', 
  as: Component = 'button', 
  size = 'md',
  ...props 
}) => {
  // Fix: Separated size classes from base classes to support the `size` prop.
  const baseClasses = 'inline-flex items-center justify-center border border-transparent font-medium rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-colors';
  
  const sizeClasses = {
    sm: 'px-2.5 py-1.5 text-sm',
    md: 'px-4 py-2 text-sm',
    lg: 'px-6 py-3 text-base',
  };

  const variantClasses = {
    primary: 'text-white bg-primary-600 hover:bg-primary-700 focus:ring-primary-500',
    secondary: 'text-primary-700 bg-primary-100 hover:bg-primary-200 focus:ring-primary-500',
    danger: 'text-white bg-red-600 hover:bg-red-700 focus:ring-red-500',
  };

  const componentProps = {
    ...props,
    className: `${baseClasses} ${sizeClasses[size]} ${variantClasses[variant]} ${className}`,
    disabled: isLoading || props.disabled,
  };

  // Fix: Handle disabled state for non-button elements like Link, which don't support the `disabled` attribute.
  if (Component !== 'button' && componentProps.disabled) {
    componentProps.onClick = (e: React.MouseEvent) => {
      e.preventDefault();
      e.stopPropagation();
    };
    componentProps.className += ' opacity-50 cursor-not-allowed';
    delete componentProps.disabled;
  }

  return (
    <Component {...componentProps}>
      {isLoading && (
        // Fix: Removed hardcoded `text-white` to allow spinner color to inherit from parent.
        <svg className="animate-spin -ml-1 mr-3 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
      )}
      {children}
    </Component>
  );
};

export default Button;
