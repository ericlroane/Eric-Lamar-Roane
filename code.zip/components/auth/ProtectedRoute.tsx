
import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth.tsx';
import type { Role } from '../../types.ts';

interface ProtectedRouteProps {
  children: JSX.Element;
  role?: Role;
}

const Spinner = () => (
    <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-primary-600"></div>
    </div>
);

export default function ProtectedRoute({ children, role }: ProtectedRouteProps) {
  const { currentUser, userProfile, loading } = useAuth();

  if (loading) {
    return <Spinner />;
  }

  if (!currentUser) {
    return <Navigate to="/login" replace />;
  }

  if (role && userProfile?.role !== role) {
    // Redirect to dashboard if user does not have the required role
    return <Navigate to="/dashboard" replace />;
  }

  return children;
}
