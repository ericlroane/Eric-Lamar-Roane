import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { signInWithEmail, signUpWithEmail } from '../../services/firebase.ts';
import Button from '../ui/Button.tsx';
import Card from '../ui/Card.tsx';

interface AuthFormProps {
  mode: 'login' | 'register';
}

export default function AuthForm({ mode }: AuthFormProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const isLogin = mode === 'login';
  const title = isLogin ? 'Welcome Back!' : 'Create Your Account';
  const buttonText = isLogin ? 'Login' : 'Register';
  const switchLinkText = isLogin ? "Don't have an account? Sign Up" : 'Already have an account? Login';
  const switchLinkTo = isLogin ? '/register' : '/login';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    // Basic validation for Super Admin password
    if (!isLogin && email.toLowerCase() === 'eric.gerconsulting@gmail.com' && password !== 'Cire100Enaor!') {
        setError("For the initial Super Admin account, the specified password must be used.");
        setLoading(false);
        return;
    }

    try {
      if (isLogin) {
        await signInWithEmail(email, password);
      } else {
        await signUpWithEmail(email, password);
      }
      navigate('/dashboard');
    } catch (err: any) {
      let friendlyMessage = 'An unknown error occurred. Please try again.';
      switch (err.code) {
        case 'auth/api-key-not-valid':
          friendlyMessage = 'Login failed: The application is not configured correctly. Please ensure the Firebase API key in `services/firebase.ts` is valid.';
          break;
        case 'auth/invalid-credential':
        case 'auth/wrong-password': // Deprecated but good for fallback
        case 'auth/user-not-found': // Deprecated but good for fallback
        case 'auth/invalid-email':
          friendlyMessage = 'Invalid email or password. Please check your credentials and try again.';
          break;
        case 'auth/email-already-in-use':
          friendlyMessage = 'An account with this email address already exists. Please login or use a different email.';
          break;
        case 'auth/weak-password':
          friendlyMessage = 'The password is too weak. It must be at least 6 characters long.';
          break;
        default:
          console.error("Firebase Auth Error:", err);
          friendlyMessage = err.message || friendlyMessage;
          break;
      }
      setError(friendlyMessage);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto">
      <Card>
        <h2 className="text-2xl font-bold text-center text-gray-800 mb-6">{title}</h2>
        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-md relative mb-4" role="alert">
            <span className="block sm:inline">{error}</span>
          </div>
        )}
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-gray-700">
              Email address
            </label>
            <input
              id="email"
              name="email"
              type="email"
              autoComplete="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
            />
          </div>
          <div>
            <label htmlFor="password" className="block text-sm font-medium text-gray-700">
              Password
            </label>
            <input
              id="password"
              name="password"
              type="password"
              autoComplete={isLogin ? 'current-password' : 'new-password'}
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
            />
          </div>
          <div>
            <Button type="submit" isLoading={loading} className="w-full">
              {buttonText}
            </Button>
          </div>
        </form>
        <div className="mt-6 text-center">
          <Link to={switchLinkTo} className="text-sm text-primary-600 hover:text-primary-500">
            {switchLinkText}
          </Link>
        </div>
      </Card>
    </div>
  );
}
