import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth.tsx';
import { signOutUser } from '../services/firebase.ts';

const MenuIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />
  </svg>
);

const CloseIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
  </svg>
);

const NavLink: React.FC<{ to: string; children: React.ReactNode; onClick?: () => void; className?: string }> = ({ to, children, onClick, className = '' }) => (
  <Link to={to} onClick={onClick} className={`transition-colors duration-200 ${className}`}>
    {children}
  </Link>
);

export default function Header() {
  const { currentUser, userProfile } = useAuth();
  const navigate = useNavigate();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    if (isMenuOpen) {
      document.body.classList.add('overflow-hidden');
    } else {
      document.body.classList.remove('overflow-hidden');
    }
    return () => {
      document.body.classList.remove('overflow-hidden');
    };
  }, [isMenuOpen]);

  const handleLogout = async () => {
    try {
      await signOutUser();
      setIsMenuOpen(false);
      navigate('/');
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  const closeMenu = () => setIsMenuOpen(false);

  return (
    <>
      <header className="bg-white/80 backdrop-blur-md shadow-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex-shrink-0">
              <Link to="/" className="text-2xl font-bold text-primary-700" onClick={closeMenu}>
                Vibe Coding <span className="font-light text-slate-500">of Augusta</span>
              </Link>
            </div>
            
            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-8">
              {currentUser ? (
                <>
                  <NavLink to="/dashboard" className="text-slate-600 hover:text-primary-600">Dashboard</NavLink>
                  {userProfile?.role === 'Super Administrator' && (
                    <NavLink to="/admin" className="text-slate-600 hover:text-primary-600">Admin Panel</NavLink>
                  )}
                  <button
                    onClick={handleLogout}
                    className="bg-primary-600 text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-primary-700 transition-colors"
                  >
                    Logout
                  </button>
                </>
              ) : (
                <>
                  <NavLink to="/login" className="text-slate-600 hover:text-primary-600">Login</NavLink>
                  <Link
                    to="/register"
                    className="bg-primary-600 text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-primary-700 transition-colors"
                  >
                    Sign Up
                  </Link>
                </>
              )}
            </nav>
            
            {/* Mobile Menu Button */}
            <div className="md:hidden">
              <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="text-slate-600 hover:text-primary-600">
                {isMenuOpen ? <CloseIcon /> : <MenuIcon />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Menu Overlay */}
      {isMenuOpen && (
        <div className="md:hidden fixed inset-0 bg-white z-40 flex flex-col items-center justify-center">
          <nav className="flex flex-col items-center space-y-8">
            {currentUser ? (
              <>
                <NavLink to="/dashboard" onClick={closeMenu} className="text-2xl text-slate-700 hover:text-primary-600">Dashboard</NavLink>
                {userProfile?.role === 'Super Administrator' && (
                  <NavLink to="/admin" onClick={closeMenu} className="text-2xl text-slate-700 hover:text-primary-600">Admin Panel</NavLink>
                )}
                <button
                  onClick={handleLogout}
                  className="bg-primary-600 text-white px-8 py-3 rounded-md text-lg font-medium hover:bg-primary-700 transition-colors"
                >
                  Logout
                </button>
              </>
            ) : (
              <>
                <NavLink to="/login" onClick={closeMenu} className="text-2xl text-slate-700 hover:text-primary-600">Login</NavLink>
                <Link
                  to="/register"
                  onClick={closeMenu}
                  className="bg-primary-600 text-white px-8 py-3 rounded-md text-lg font-medium hover:bg-primary-700 transition-colors"
                >
                  Sign Up
                </Link>
              </>
            )}
          </nav>
        </div>
      )}
    </>
  );
}
