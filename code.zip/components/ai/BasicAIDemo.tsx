import React, { useState } from 'react';
import { getPublicSparkResponse } from '../../services/aiService.ts';
import Card from '../ui/Card.tsx';
import Button from '../ui/Button.tsx';

const SparkIcon = () => <div className="w-8 h-8 rounded-full bg-primary-200 flex items-center justify-center font-bold text-primary-700 flex-shrink-0">S</div>;

export default function BasicAIDemo() {
  const [prompt, setPrompt] = useState('');
  const [response, setResponse] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) return;

    setIsLoading(true);
    setError('');
    setResponse('');

    try {
      // FIX: Call the new public-facing cloud function for the demo
      const result = await getPublicSparkResponse(prompt);
      if (result.includes("I'm sorry")) {
          setError(result);
          setResponse('');
      } else {
          setResponse(result);
      }
    } catch (err) {
      setError("An unexpected error occurred. Please check the console for details.");
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="bg-primary-50 border border-primary-200">
      <h2 className="text-2xl font-bold text-center mb-2 text-primary-800">Try Spark AI Now!</h2>
      <p className="text-center text-slate-600 mb-6">Get a feel for our basic AI. Ask a question to see how it can help you.</p>
      
      <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-2">
        <input
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="e.g., How can I be more productive?"
          className="flex-grow p-3 border border-slate-300 rounded-md focus:ring-primary-500 focus:border-primary-500 transition"
          disabled={isLoading}
        />
        <Button type="submit" isLoading={isLoading} size="lg">Ask Spark</Button>
      </form>

      {error && (
        <div className="mt-4 text-center bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-md">
          {error}
        </div>
      )}

      {isLoading && !response && !error && (
        <div className="mt-4 flex justify-center items-center gap-3 text-slate-600">
          <SparkIcon />
          <span>Spark is thinking...</span>
          <div className="flex items-center space-x-1">
            <div className="w-2 h-2 bg-slate-400 rounded-full animate-pulse"></div>
            <div className="w-2 h-2 bg-slate-400 rounded-full animate-pulse [animation-delay:0.2s]"></div>
            <div className="w-2 h-2 bg-slate-400 rounded-full animate-pulse [animation-delay:0.4s]"></div>
          </div>
        </div>
      )}

      {response && (
        <div className="mt-6 p-4 bg-white rounded-lg shadow-inner">
          <div className="flex items-start gap-3">
            <SparkIcon />
            <p className="text-slate-700 whitespace-pre-wrap">{response}</p>
          </div>
        </div>
      )}
    </Card>
  );
}
