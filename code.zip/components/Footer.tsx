
import React from 'react';

export default function Footer() {
  return (
    <footer className="bg-white">
      <div className="container mx-auto py-6 px-4 sm:px-6 lg:px-8 text-center text-slate-500">
        <p>&copy; {new Date().getFullYear()} Vibe Coding of Augusta. All rights reserved.</p>
        <p className="text-sm mt-1">Making AI easy, one vibe at a time.</p>
      </div>
    </footer>
  );
}
