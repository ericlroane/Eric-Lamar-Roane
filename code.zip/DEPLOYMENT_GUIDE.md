# Vibe Coding of Augusta - Deployment Guide

This guide provides the final steps to deploy your complete web application, including the secure backend Cloud Functions, to Firebase.

## API Key and Credentials Summary

To make the application fully operational, you only need to secure **two** items from your Google Cloud/Firebase project.

### 1. Google Gemini API Key
-   **Purpose:** This key allows your secure backend (Cloud Function) to make calls to the Gemini AI model. It is the key that powers the entire AI chat functionality.
-   **How it's Used:** You will set this as a secret environment variable using the Firebase CLI (see Step 4).
-   **URL to get key:** **[https://aistudio.google.com/app/apikey](https://aistudio.google.com/app/apikey)**

### 2. Firebase Admin SDK Service Account Key
-   **Purpose:** This is a JSON file that grants your local, command-line scripts (`admin-scripts/`) full administrative access to your Firebase project. It is used for tasks like managing user roles from your own computer.
-   **How it's Used:** You will download this file and place it in the `admin-scripts` directory.
-   **URL to get key file:** **[https://console.firebase.google.com/project/studio-2047789106-e4e02/settings/serviceaccounts/adminsdk](https://console.firebase.google.com/project/studio-2047789106-e4e02/settings/serviceaccounts/adminsdk)**

**No other API keys or credentials are needed for this application.**

---

## Prerequisites

1.  **Node.js and npm:** Ensure you have Node.js (version 18 or later) and npm installed on your machine.
2.  **Firebase Account:** You must have a Firebase account and have already created the project.
3.  **Gemini API Key:** You have provided this key.

## Step 1: Install the Firebase CLI

The Firebase Command Line Interface (CLI) is essential for deploying and managing your Firebase project. If you don't have it installed, open your terminal and run this command:

```bash
npm install -g firebase-tools
```

## Step 2: Login to Firebase

In your terminal, log in to your Firebase account. This will open a browser window for you to authenticate.

```bash
firebase login
```

## Step 3: Initialize Firebase in Your Project

Navigate to the root directory of your project in the terminal. If you have already initialized Firebase, you can skip this step. If not, run:

```bash
firebase init
```

When prompted, select the features you are using: **Hosting** and **Functions**. Follow the on-screen instructions, and be sure to connect it to your existing project (`studio-2047789106-e4e02`).

## Step 4: Set the Secret Gemini API Key (CRITICAL)

Your Cloud Function needs the Gemini API key to work. This command will securely store the key in Google's Secret Manager, making it available to your backend.

**Run the following command in your terminal. This is the exact command you need:**

```bash
firebase functions:secrets:set GEMINI_API_KEY
```

When prompted, paste your Gemini API key: `c081c44a4aa824d82739fccc23c57f23aded1033` and press Enter.

**Important:** You only need to do this once. The secret will be remembered for all future deployments.

## Step 5: Deploy Your Application

This is the final step. In your project's root directory, run the deploy command. This command will build and upload your frontend (Hosting) and your backend (Cloud Functions) to Firebase.

```bash
firebase deploy
```

The deployment process may take a few minutes. Once it's complete, the terminal will display your live application URL.

---

### Summary of Your Production-Ready Architecture

-   **Frontend:** A React single-page application served globally via Firebase Hosting's CDN for high speed.
-   **Backend:** A secure Node.js environment running on Firebase Cloud Functions.
-   **Security:** The Gemini API key is stored securely in Google Secret Manager and is **never** exposed to the client. The frontend client calls the backend function, which then safely calls the Gemini API.
-   **Database:** User data, roles, and subscriptions are managed in Firestore.
-   **Administration:** You can manage user roles directly from the command line using the scripts in the `admin-scripts` directory, which use a secure service account key.

Your application is now complete and follows modern best practices for security and deployment.
