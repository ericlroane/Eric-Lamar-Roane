export const ROLES = ['Super Administrator', 'Administrator', 'Manager', 'Salesperson', 'AI Helper'] as const;
export type Role = typeof ROLES[number];

export type Plan = 'spark-basic' | 'spark-pro';

export interface UserProfile {
  uid: string;
  email: string | null;
  role: Role;
  name?: string;
  job?: string;
  birthday?: string;
  subscription?: 'Spark Basic' | 'Spark Pro' | null;
  subscriptionEndDate?: string | null;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
}

export interface LearningArticle {
  slug: string;
  title: string;
  summary: string;
  isPro: boolean;
  content: string;
}
