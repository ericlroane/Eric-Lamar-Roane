# Vibe Coding - Firebase Admin Scripts

This directory contains scripts for performing administrative actions on your Firebase project from your local machine. These scripts use the Firebase Admin SDK, which grants them privileged access to your project's data.

**WARNING: These scripts have full administrative access to your project. Handle the `serviceAccountKey.json` file with extreme care. Do not commit it to version control or share it publicly.**

## 1. Setup: Get Your Service Account Key

Before you can run these scripts, you need to download your project's service account key.

1.  **Go to your Firebase Project Console:** [https://console.firebase.google.com/](https://console.firebase.google.com/)
2.  Select your project (`studio-2047789106-e4e02`).
3.  Click the **gear icon** next to "Project Overview" in the top-left, and select **Project settings**.
4.  Go to the **Service accounts** tab.
5.  Click the **"Generate new private key"** button. A warning will appear; click **"Generate key"**.
6.  A JSON file will be downloaded. **Rename this file to `serviceAccountKey.json`**.
7.  **Move the `serviceAccountKey.json` file into this `admin-scripts` directory.**

## 2. Installation

Navigate to this directory in your terminal and install the required dependencies.

```bash
cd admin-scripts
npm install
```

## 3. Usage

The `manageUsers.js` script allows you to list users and manage their roles.

### List All Users

This command will print a table of all users in your Firebase project, showing their UID, email, and current role.

```bash
node manageUsers.js --list
```

### Set a User's Role

This command will find a user by their email address and update their role in the database.

**Syntax:**
`node manageUsers.js --setRole <email> <role>`

**Available Roles:**
`Super Administrator`, `Administrator`, `Manager`, `Salesperson`, `AI Helper`

**Example:**
To make `test@example.com` a `Manager`:

```bash
node manageUsers.js --setRole test@example.com Manager
```
