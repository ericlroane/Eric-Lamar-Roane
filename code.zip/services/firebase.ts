import { initializeApp } from 'firebase/app';
import { getAnalytics } from 'firebase/analytics';
import { 
  getAuth, 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  signOut, 
  onAuthStateChanged,
  type User
} from 'firebase/auth';
import { 
  getFirestore, 
  doc, 
  setDoc, 
  getDoc, 
  collection, 
  getDocs,
  updateDoc
} from 'firebase/firestore';
import { getFunctions } from 'firebase/functions';
import type { UserProfile, Role } from '../types.ts';

// FIX: The API key had a typo. It has been replaced with the correct key from your Firebase project settings.
// This resolves the "auth/api-key-not-valid" error.
const firebaseConfig = {
  apiKey: "AIzaSyBvhFciifKivZKhbJWWSfH700tNG97Rp04",
  authDomain: "studio-2047789106-e4e02.firebaseapp.com",
  databaseURL: "https://studio-2047789106-e4e02-default-rtdb.firebaseio.com",
  projectId: "studio-2047789106-e4e02",
  storageBucket: "studio-2047789106-e4e02.firebasestorage.app",
  messagingSenderId: "187277438465",
  appId: "1:187277438465:web:458bb8d7bd4b8d52191a00",
  measurementId: "G-D2TJT0N1W7"
};

const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app); // Initialize Firebase Analytics

export const auth = getAuth(app);
export const db = getFirestore(app);
export const functions = getFunctions(app); // Initialize and export Firebase Functions

// --- AUTH FUNCTIONS ---

export const signUpWithEmail = async (email: string, password: string) => {
  const userCredential = await createUserWithEmailAndPassword(auth, email, password);
  const user = userCredential.user;
  await createUserProfile(user);
  return user;
};

export const signInWithEmail = (email: string, password: string) => {
  return signInWithEmailAndPassword(auth, email, password);
};

export const signOutUser = () => {
  return signOut(auth);
};

export const onAuthStateChange = (callback: (user: User | null) => void) => {
  return onAuthStateChanged(auth, callback);
};

// --- FIRESTORE FUNCTIONS ---

export const createUserProfile = async (user: User) => {
  const userRef = doc(db, 'users', user.uid);
  const newUserProfile: UserProfile = {
    uid: user.uid,
    email: user.email,
    role: 'AI Helper',
    subscription: null,
  };
  await setDoc(userRef, newUserProfile);
  return newUserProfile;
};

export const getUserProfile = async (uid: string): Promise<UserProfile | null> => {
  const userRef = doc(db, 'users', uid);
  const docSnap = await getDoc(userRef);
  if (docSnap.exists()) {
    return docSnap.data() as UserProfile;
  }
  return null;
};

export const updateUserProfile = async (uid: string, data: Partial<UserProfile>) => {
  const userRef = doc(db, 'users', uid);
  await updateDoc(userRef, data);
};

export const getAllUsers = async (): Promise<UserProfile[]> => {
  const usersCol = collection(db, 'users');
  const userSnapshot = await getDocs(usersCol);
  const userList = userSnapshot.docs.map(doc => doc.data() as UserProfile);
  return userList;
};

export const updateUserRole = async (uid: string, role: Role) => {
  const userRef = doc(db, 'users', uid);
  await updateDoc(userRef, { role });
};

export const updateUserSubscription = async (uid: string, planName: 'Spark Basic' | 'Spark Pro') => {
  const userRef = doc(db, 'users', uid);
  const subscriptionEndDate = new Date();
  // Set trial or subscription period
  const days = planName === 'Spark Basic' ? 3 : 30;
  subscriptionEndDate.setDate(subscriptionEndDate.getDate() + days);

  await updateDoc(userRef, {
    subscription: planName,
    subscriptionEndDate: subscriptionEndDate.toISOString().split('T')[0], // Store as YYYY-MM-DD
  });
};

export const initializeSuperAdmin = async (user: User) => {
    if (user.email === 'eric.gerconsulting@gmail.com') {
        const profile = await getUserProfile(user.uid);
        if (profile && profile.role !== 'Super Administrator') {
            await updateUserRole(user.uid, 'Super Administrator');
            console.log('Super Administrator role assigned.');
            return { ...profile, role: 'Super Administrator' as Role };
        }
        return profile;
    }
    return await getUserProfile(user.uid);
};
