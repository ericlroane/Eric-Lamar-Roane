import { httpsCallable } from 'firebase/functions';
import { functions } from './firebase.ts';
import type { UserProfile, ChatMessage } from '../types.ts';

type Enhancement = '0-shot' | '1-shot' | 'few-shot' | 'chain-prompt';

// Callable for authenticated users with full features
const getSparkResponseCallable = httpsCallable(functions, 'getSparkResponse');

// Callable for the public, unauthenticated demo
const getPublicSparkResponseCallable = httpsCallable(functions, 'getPublicSparkResponse');


const applyEnhancement = (prompt: string, enhancement: Enhancement): string => {
    switch (enhancement) {
        case '1-shot':
            return `Example:
User: How can I improve my time management?
AI: A great way to start is by using the Eisenhower Matrix to prioritize tasks into four quadrants: Urgent/Important, Not Urgent/Important, Urgent/Not Important, and Not Urgent/Not Important. This helps you focus on what truly matters.

Now, answer the following:
User: ${prompt}`;
        case 'few-shot':
            return `Example 1:
User: What's a simple way to learn a new skill?
AI: A proven method is 'deliberate practice'. Break the skill into small components, practice them intensely, and get immediate feedback to correct your course. Consistency is key!

Example 2:
User: I feel unmotivated. Any tips?
AI: Try the '2-Minute Rule'. If a task takes less than two minutes, do it immediately. This builds momentum and makes bigger tasks feel less daunting.

Now, answer the following:
User: ${prompt}`;
        case 'chain-prompt':
            return `Think step-by-step to provide the most logical and helpful answer to the user's question. First, identify the core problem or question. Second, break it down into smaller, manageable parts. Third, address each part in a clear sequence. Finally, summarize the solution.

User's question: ${prompt}`;
        case '0-shot':
        default:
            return prompt;
    }
};

// For authenticated users on the dashboard
export const getSparkResponse = async (
    prompt: string,
    persona: Partial<UserProfile>,
    enhancement: Enhancement,
    history: ChatMessage[] = []
): Promise<string> => {
    try {
        const enhancedPrompt = applyEnhancement(prompt, enhancement);

        const response = await getSparkResponseCallable({
            prompt: enhancedPrompt,
            persona,
            enhancement,
            history
        });
        
        const data = response.data as { text: string };
        return data.text;

    } catch (error: any) {
        console.error("Error calling getSparkResponse Cloud Function:", error);
        if (error.code === 'unauthenticated') {
            return "I'm sorry, you must be logged in to use this feature.";
        }
        return "I'm sorry, I encountered an issue while processing your request. Please check the console for more details.";
    }
};

// For the public demo on the homepage
export const getPublicSparkResponse = async (prompt: string): Promise<string> => {
    try {
        const response = await getPublicSparkResponseCallable({ prompt });
        const data = response.data as { text: string };
        return data.text;
    } catch (error: any) {
        console.error("Error calling getPublicSparkResponse Cloud Function:", error);
        return "I'm sorry, the public demo is currently experiencing issues. Please try again later.";
    }
};
